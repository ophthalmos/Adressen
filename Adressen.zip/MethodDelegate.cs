﻿namespace Adressen;

internal class MethodDelegate
{
}