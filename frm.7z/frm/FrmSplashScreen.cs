﻿namespace Adressen.frm;

public partial class FrmSplashScreen : Form
{
    public FrmSplashScreen()
    {
        InitializeComponent();
    }
}
